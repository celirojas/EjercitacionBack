package com.dh.flyweigth.model;

import com.dh.flyweigth.factory.CancionFactory;

import java.util.ArrayList;
import java.util.List;

public class ListaReproduccion {
    private String nombre;
    private List<Cancion> listaCanciones = new ArrayList<>();

    public ListaReproduccion(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Cancion> getListaCanciones() {
        return listaCanciones;
    }

    public void setListaCanciones(List<Cancion> listaCanciones) {
        this.listaCanciones = listaCanciones;
    }

    public void listarCancion(){
        System.out.println("Esta son las canciones");
        for (Cancion cancion: listaCanciones) {
            System.out.println("Cancion:" + cancion.getNombre());
        }
    }
    public void agregarCancion(String nombre){
        listaCanciones.add(CancionFactory.obtenerCancion(nombre));
        System.out.println("Agregando la canción:" + nombre);
    }

    public void borrarCancion(String nombre){
        for (Cancion cancion: listaCanciones
             ) {
            if(cancion.getNombre().equals(nombre)){
                listaCanciones.remove(cancion);
                System.out.println("Removiendo la canción:" + cancion);
                break;
            }
        }

    }
}