package com.dh.flyweigth.factory;

import com.dh.flyweigth.model.Cancion;

import java.util.HashMap;

public class CancionFactory {
    private static final HashMap<String, Cancion> CANCION_MAP = new HashMap<>(); //Creando método mapa de canciones que tiene como key: nombre. Se carga en memoria y queda guardado en cache

    public static Cancion obtenerCancion(String nombre){//Método obtener canción
        Cancion cancion =  CANCION_MAP.get(nombre); //Creando una canción
        if (cancion == null){ //Evaluando si la canción es nula, entonces que cree la canción con ese nombre
            cancion = new Cancion(nombre);
            CANCION_MAP.put(nombre, cancion);
            System.out.println("Creando objeto de canción con el nombre:" + nombre);
            return cancion;
        }
        System.out.println("Recuperando Objecto de canción con el nombre: " + nombre);//Si la condicion existe, que retorne la canción
        return cancion;
    }

}
