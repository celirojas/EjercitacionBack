package com.dh.flyweigth.model;

public class Cancion {
    private String nombre; //Atributo compartido

    private String artista;
    private String genero;

    public Cancion(String nombre) { //Constructor del atributo compartido
        this.nombre = nombre;
    }

    public String getArtista() { //Métodos accesores de los atributos NO compartidos
        return artista;
    }

    public String getNombre() {
        return nombre;
    }
    public void setArtista(String artista) {
        this.artista = artista;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
}
