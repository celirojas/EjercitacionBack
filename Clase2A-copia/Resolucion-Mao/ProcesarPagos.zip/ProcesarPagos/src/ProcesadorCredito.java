public class ProcesadorCredito extends ProcesadorPagos {

    public ProcesadorCredito() {
    }

    public boolean autorizarPago(Tarjeta tarjeta, double valor) {
        TarjetaCredito t = (TarjetaCredito)tarjeta;
        return t.getLimite() - t.getSaldoUtilizado() >= valor;
    }

    public void realizarPago(Tarjeta tarjeta, double valor) {
        TarjetaCredito t = (TarjetaCredito)tarjeta;
        t.setSaldoUtilizado(t.getSaldoUtilizado() + valor);
    }
}
