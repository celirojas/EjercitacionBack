import java.time.LocalDate;
import java.time.Period;

public abstract class ProcesadorPagos {

    public void procesarPago(Tarjeta tarjeta, double valor) {
        LocalDate today = LocalDate.now();
        if (!validarFechaDeExpiracion(tarjeta, today)) {
            System.out.println("La tarjeta ha caducado.");
        } else if (!autorizarPago(tarjeta, valor)) {
            System.out.println("No hay fondos suficientes para realizar la operación");
        } else {
            realizarPago(tarjeta, valor);
        }
    }

    public boolean validarFechaDeExpiracion(Tarjeta tarjeta, LocalDate fecha) {
        return Period.between(fecha, tarjeta.getFechaExpiracion()).getDays() > 0;
    }

    public abstract boolean autorizarPago(Tarjeta tarjeta,double valor);

    public abstract void realizarPago(Tarjeta tarjeta, double valor);
}
