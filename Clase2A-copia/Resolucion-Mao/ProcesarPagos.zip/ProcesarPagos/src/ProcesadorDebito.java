public class ProcesadorDebito extends ProcesadorPagos {

    public ProcesadorDebito() {
    }

    @Override
    public boolean autorizarPago(Tarjeta tarjeta, double valor) {
        TarjetaDebito t = (TarjetaDebito)tarjeta;
        return t.getSaldoDisponible() >= valor;
    }

    @Override
    public void realizarPago(Tarjeta tarjeta, double valor) {
        TarjetaDebito t = (TarjetaDebito)tarjeta;
        t.setSaldoDisponible(t.getSaldoDisponible() - valor);
    }
}
