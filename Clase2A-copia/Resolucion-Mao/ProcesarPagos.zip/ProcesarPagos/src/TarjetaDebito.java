import java.time.LocalDate;

public class TarjetaDebito extends Tarjeta{

    private double saldoDisponible;

    public TarjetaDebito(Long numerosFrente, int codigoSeguridad, LocalDate fechaExpiracion, double saldoDisponible) {
        super(numerosFrente, codigoSeguridad, fechaExpiracion);
        this.saldoDisponible = saldoDisponible;
    }

    public double getSaldoDisponible() {
        return saldoDisponible;
    }

    public void setSaldoDisponible(double saldoDisponible) {
        this.saldoDisponible = saldoDisponible;
    }
}
