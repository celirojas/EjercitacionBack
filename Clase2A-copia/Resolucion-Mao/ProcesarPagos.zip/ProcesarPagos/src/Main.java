import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        TarjetaDebito t1 = new TarjetaDebito((long)1020304050, 123, LocalDate.of(2025,12,30), 100000);
        ProcesadorDebito p1 = new ProcesadorDebito();
        p1.procesarPago(t1, 60000);
        System.out.println("Saldo final: " + t1.getSaldoDisponible());

        TarjetaCredito t2 = new TarjetaCredito((long)1122334455, 456, LocalDate.of(2022, 12, 30),300000, 0);
        ProcesadorCredito p2 = new ProcesadorCredito();
        p2.procesarPago(t2, 150000);
        System.out.println("Saldo utilizado: " + (t2.getSaldoUtilizado()));
        System.out.println("Cupo disponible: " + (t2.getLimite() - t2.getSaldoUtilizado()));
        p2.procesarPago(t2, 250000);
        System.out.println("Saldo utilizado: " + (t2.getSaldoUtilizado()));
        System.out.println("Cupo disponible: " + (t2.getLimite() - t2.getSaldoUtilizado()));
    }
}
