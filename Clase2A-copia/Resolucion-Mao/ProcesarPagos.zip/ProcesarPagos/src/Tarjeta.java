import java.time.LocalDate;

public abstract class Tarjeta {
    protected Long numerosFrente;
    protected int codigoSeguridad;
    protected LocalDate fechaExpiracion;

    public Tarjeta(Long numerosFrente, int codigoSeguridad, LocalDate fechaExpiracion) {
        this.numerosFrente = numerosFrente;
        this.codigoSeguridad = codigoSeguridad;
        this.fechaExpiracion = fechaExpiracion;
    }

    public Long getNumerosFrente() {
        return numerosFrente;
    }

    public void setNumerosFrente(Long numerosFrente) {
        this.numerosFrente = numerosFrente;
    }

    public int getCodigoSeguridad() {
        return codigoSeguridad;
    }

    public void setCodigoSeguridad(int codigoSeguridad) {
        this.codigoSeguridad = codigoSeguridad;
    }

    public LocalDate getFechaExpiracion() {
        return fechaExpiracion;
    }

    public void setFechaExpiracion(LocalDate fechaExpiracion) {
        this.fechaExpiracion = fechaExpiracion;
    }


}
