//import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;


class PersonaTest {
    @Test
    void obtenerNombreCompleto() {
        Persona persona = new Persona("Mauricio", "Pineda", "ingmauriciopineda@gmail.com", LocalDate.of(1982,10,28));
        assertEquals("Mauricio Pineda", persona.obtenerNombreCompleto());
    }

    @Test
    void esMayorDeEdad() {
        Persona persona = new Persona("Mauricio", "Pineda", "ingmauriciopineda@gmail.com", LocalDate.of(1982,10,28));
        //assertEquals(true, persona.esMayorDeEdad());
        assertTrue(persona.esMayorDeEdad());
    }
}