import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Persona persona1 = new Persona("Juan", "Pérez", "jperez@gmail.com", LocalDate.of(1982,10,28));
        System.out.println(persona1.getEdad());
    }
}
