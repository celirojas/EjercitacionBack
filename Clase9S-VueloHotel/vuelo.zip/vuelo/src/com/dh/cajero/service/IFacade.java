package com.dh.cajero.service;

import java.time.LocalDate;

public interface IFacade {

    public void buscarHotelYVuelo(String ciudad , LocalDate fechaSalida);
}
