package com.dh.cajero.service.imp;

import com.dh.cajero.model.Hotel;
import com.dh.cajero.model.Vuelo;
import com.dh.cajero.service.IFacade;

import java.time.LocalDate;
import java.util.List;

public class FacadeImpl  implements IFacade {
    private VueloService vueloService;
    private HotelService hotelService;

    public FacadeImpl(VueloService vueloService, HotelService hotelService) {
        this.vueloService = vueloService;
        this.hotelService = hotelService;
    }

    public VueloService getVueloService() {
        return vueloService;
    }

    public HotelService getHotelService() {
        return hotelService;
    }

    @Override
    public void buscarHotelYVuelo(String ciudad, LocalDate fechaSalida) {
        List<Vuelo> vuelos = vueloService.buscarVuelo(fechaSalida, ciudad);
        List<Hotel> hoteles = hotelService.buscarHotel(fechaSalida, ciudad);

        for (Vuelo vuelo:vuelos) {
                System.out.println(vuelo.toString());
        }
        for (Hotel hotel: hoteles) {
            System.out.println(hotel.toString());
        }

    }
}
